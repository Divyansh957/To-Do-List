# Professional To‑Do List (Vanilla JS)
A single‑page to‑do app with add/edit/delete, priorities, search, filters, and localStorage.

## Quick start
1. Open `index.html` in a browser.
2. All data is saved locally.
